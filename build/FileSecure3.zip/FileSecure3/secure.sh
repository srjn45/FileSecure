sudo java -jar /opt/FileSecure/secure-v3.1.jar
