sudo rm -rf /opt/FileSecure
sudo mkdir /opt/FileSecure
sudo cp secure-v2.1.jar /opt/FileSecure/secure-v2.1.jar
sudo cp secure.sh /opt/FileSecure/secure
sudo chmod -R 755 /opt/FileSecure
