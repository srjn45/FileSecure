sudo java -jar /opt/FileSecure/secure-v2.1.jar
